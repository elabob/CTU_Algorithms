//
// Created by bobenade on 20/12/2025.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>   //na cas

struct State {
    int last_sum;
    int total_valves;
};

bool compare(const State &a, const State &b) {
    if (a.total_valves != b.total_valves) {
        return a.total_valves > b.total_valves;
    }
    return a.last_sum > b.last_sum;
}

int main() {
    // SPUSTIT STOPKY
    auto start_time = std::chrono::high_resolution_clock::now();

    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int num_row, num_column;
    if (!(std::cin >> num_row >> num_column)) return 0;

    // if (num_row < 5 || num_column > 200) {
    //     std::cout<< "Wrong input \n";
    //     return 1;
    // }

    std::vector<std::vector<int>> matrix(num_row);
    for (int i=0; i< num_row; i++) {
        for (int j=0; j<num_column; j++) {
            int number;
            std::cin>>number;
            matrix[i].push_back(number);
        }
    }

    //KONTROLA vyprintenia vektoru
     // for (auto &row : matrix) {
     //     for (int x : row) {
     //         std::cout << x << ' ';
     //     }
     //     std::cout<< "\n";
     // }

    //pre vodorovne potrubie vodovodu
    std::vector<std::vector<int>>row_prefix(num_row);
    for (int i=0; i< num_row ; i++) {
        for (int j=0; j<num_column; j++) {
            if (j == 0) {
                row_prefix[i].push_back(matrix[i][j]);
            }else if (j>0) {
                int prefix;
                prefix = matrix[i][j]+ row_prefix[i][j-1];
                row_prefix[i].push_back(prefix);

            }
            }
        }

    //pre zvisle potrubie vodovodu
    std::vector<std::vector<int>> column_prefix(num_row);
    for (int i=0; i< num_row ; i++) {
        for (int j=0; j<num_column; j++) {
            if (i == 0) {
                column_prefix[i].push_back(matrix[i][j]);
            }else {
                int prefix;
                prefix = matrix[i][j] + column_prefix[i-1][j];
                column_prefix[i].push_back(prefix);

            }
        }
    }

    // //KONTROLNY vypis prefixovej matice (stlpcovej)
    // for (auto &column : column_prefix) {
    //         for (int x : column) {
    //             std::cout << x << ' ';
    //         }
    //         std::cout<< "\n";
    //     }

    // KONTROLNY vypis prefixovej matice (riadkovej)
    // for (auto &row : row_prefix) {
    //         for (int x : row) {
    //             std::cout << x << ' ';
    //         }
    //         std::cout<< "\n";
    //     }

    // Pouzijeme static pre velke polia, aby sme nezatazovali stack (nie je nutne, ale bezpecnejsie)
    static std::vector<State> dynamic_vertical_path[205][205];
    static std::vector<State> dynamic_horizontal_path[205][205];

    //start v [0][0] ([riadok][stlpec])


    dynamic_vertical_path[0][0].push_back({100000000,0});
    dynamic_horizontal_path[0][0].push_back({100000000,0});  //zamerne som prve cislo v {} zvolila co najvacsie kedze pravidla hovoria ze nasledujuci usek musi byty mensi ako predosly... tak nieco taketo velke to urcite zabezpeci; druhe cislo je 0 lebo na starte mam 0 ventilov


    // global_max_valves tu nepocitam priebezne, lebo cesta musi koncit v cieli --> to bola predtym moja chyba

    for (int i=0; i < num_row; i++) {
        for (int j = 0; j < num_column; j++) {

            // preskocim [0][0], tam uz mam startovacie hodnoty
            if (i == 0 && j == 0) continue;

            for (int k = 0; k< j; k++) {
                //vodorovne
                // Ak v predchadzajucom bode nie su ziadne cesty, nemusim nic pocitat
                if (dynamic_vertical_path[i][k].empty()) continue;

                int current_sum = row_prefix[i][j - 1] - row_prefix[i][k];

                // Teraz sa pozriem do bodu zlomu [i][k], kedze teraz idem vodorovne, musela som tam prist ZVISLO (pravidlo striedania smerov).
                // Prejdem vsetky moznosti, ktore su ulozene v dynamic_vertical_path[i][k]
                for (auto &prev_state : dynamic_vertical_path[i][k]) {

                    // Podmienka klesania: Novy usek musi byt mensi ako predosly
                    if (prev_state.last_sum > current_sum) {

                        // Nasla som platnu cestu :) Vytvorim novy stav.
                        State new_state;
                        new_state.last_sum = current_sum;
                        new_state.total_valves = prev_state.total_valves + current_sum;

                        // Ulozim ho do dynamic_horizontal_path (lebo som prisla vodorovne)
                        dynamic_horizontal_path[i][j].push_back(new_state);

                        // Kedze prev_state su zoradene zostupne podla poctu ventilov, prvy, ktory najdem a splna podmienku, je ten najlepsi pre dane 'k'.
                        // Dalsie stavy v tomto zozname maju menej alebo rovnako ventilov, takze nema zmysel ich skusat (vytvorili by horsie stavy).
                        break;
                    }
                }
            }

            // cistenie po cykle
            if (dynamic_horizontal_path[i][j].size() > 0) {
                std::sort(dynamic_horizontal_path[i][j].begin(),
                dynamic_horizontal_path[i][j].end(), compare);
                int p = 0;
                int max_limit = -1;
                for (const auto& s : dynamic_horizontal_path[i][j]) {
                    // Necham len ak ma lepsi limit (last_sum), pretoze ak ma menej ventilov (vynutene sortom), musi mat aspon vacsiu "rezervu" (last_sum) pre buduci tah, inak je zbytocny.
                    if (s.last_sum > max_limit) {
                        dynamic_horizontal_path[i][j][p++] = s;
                        max_limit = s.last_sum;
                    }
                }
                dynamic_horizontal_path[i][j].resize(p);
            }

            for (int k = 0; k< i; k++) {
                //zvislo
                if (dynamic_horizontal_path[k][j].empty()) continue;

                int current_sum = column_prefix[i - 1][j] - column_prefix[k][j];

                // Teraz sa pozriem do bodu zlomu [k][j], kedze teraz idem zvislo, musela som tam prist VODOROVNE (pravidlo striedania smerov).
                // Prejdem vsetky moznosti, ktore su ulozene v dynamic_horizontal_path[k][j]
                for (auto &prev_state : dynamic_horizontal_path[k][j]) {

                    // Podmienka klesania: Novy usek musi byt mensi ako predosly
                    if (prev_state.last_sum > current_sum) {

                        // Nasla som platnu cestu :). Vytvorim novy stav.
                        State new_state;
                        new_state.last_sum = current_sum;
                        new_state.total_valves = prev_state.total_valves + current_sum;

                        // Ulozim ho do dynamic_vertical_path (lebo som prisla zvislo)
                        dynamic_vertical_path[i][j].push_back(new_state);

                        // Optimalizacia - break, nasli sme najlepsi pre dane k
                        break;
                    }
                }
            }

            // cistenie
            if (dynamic_vertical_path[i][j].size() > 0) {
                std::sort(dynamic_vertical_path[i][j].begin(),
                dynamic_vertical_path[i][j].end(), compare);
                int p = 0;
                int max_limit = -1;
                for (const auto& s : dynamic_vertical_path[i][j]) {
                    if (s.last_sum > max_limit) {
                        dynamic_vertical_path[i][j][p++] = s;
                        max_limit = s.last_sum;
                    }
                }
                dynamic_vertical_path[i][j].resize(p);
            }
        }
    }

    // Len pre kontrolu [0][0] alebo malej oblasti
    // for (int i = 0; i < num_row; i++) {
    //     for (int j = 0; j < num_column; j++) {
    //         // Ak je na policku nejaky zaznam
    //         if (!dynamic_vertical_path[i][j].empty()) {
    //             std::cout << "Policko [" << i << "][" << j << "]: ";
    //             // Vypisem vsetky stavy v danom policku
    //             for (auto &s : dynamic_vertical_path[i][j]) {
    //                 std::cout << "{Sum:" << s.last_sum << ", Val:" << s.total_valves << "} ";
    //             }
    //             std::cout << "\n";
    //         }
    //     }
    // }

    // Hladam maximum az na konci, iba v cielovej bunke [num_row-1][num_column-1]
    int final_result = 0;

    // Pozriem vsetky moznosti, ktore skoncili v cieli vodorovne
    for (const auto& s : dynamic_horizontal_path[num_row-1][num_column-1]) {
        if (s.total_valves > final_result) final_result = s.total_valves;
    }
    // Pozriem vsetky moznosti, ktore skoncili v cieli zvislo
    for (const auto& s : dynamic_vertical_path[num_row-1][num_column-1]) {
        if (s.total_valves > final_result) final_result = s.total_valves;
    }

    std::cout << final_result;

    // ZASTAVIT STOPKY A VYPISAT CAS
    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end_time - start_time;

    //std::cerr << "\n Time taken: " << elapsed.count()
    //<< "s" << std::endl;
}
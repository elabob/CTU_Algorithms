//
// Created by bobenade on 10/10/2025.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <climits>

struct AdjNode {
    int vertex;
    AdjNode* next;
    AdjNode(int v) : vertex(v), next(nullptr) {}
};

int best_score = INT_MIN / 2;
int num_vertices;

// predpocitam si zisky pre kazdy vrchol a typ agenta
int precomputed_gain[31][3]; // [vertex][agent_type: 0=none, 1=T1, 2=T2]

// rychle pole susedov pre kazdy vrchol (zlepsuje cache lokalitu)
int neighbor_count[31];
int neighbors[31][31];

// toto je hlavna optimalizovana funkcia pre branch and bound s cachingom
void branch_and_bound(int current_index, int t1_remaining, int t2_remaining, int* agent_placement, int current_network_score,
                const int* vertex_order, const int* vertex_degree, int* best_possible_add) {

    // ked som presla vsetky vrcholy tak checkneme ci to je lepsi vysledok
    if (current_index == num_vertices) {
        if (t1_remaining == 0 && t2_remaining == 0 && current_network_score > best_score) {
            best_score = current_network_score;
        }
        return;
    }

    int vertices_left = num_vertices - current_index;
    // ak mam viac agentov nez vrcholov tak to nema zmysel
    if (t1_remaining + t2_remaining > vertices_left) return;

    // tu pocitam optimisticky upper bound aby som mohla prerezavat vetve
    // beriem len najlepsie mozne pridavky z vrcoholov co este zostali
    int optimistic_upper_bound = current_network_score;
    for (int i = current_index; i < num_vertices && (t1_remaining > 0 || t2_remaining > 0); i++) {
        optimistic_upper_bound += best_possible_add[i];
        if (i - current_index + 1 >= t1_remaining + t2_remaining) break;
    }

    // ak aj v najlepsom pripade nemozem prelozit current best tak prerezavam
    if (optimistic_upper_bound <= best_score) return;

    int vertex = vertex_order[current_index];
    int neighbor_cnt = neighbor_count[vertex];

    // skusim dat T1 agenta na tento vrchol
    if (t1_remaining > 0) {
        agent_placement[vertex] = 1;
        int score_delta = 0;

        // prejdem susedov a pocitam kolko bodov mi to prida
        // T1 s T1 je +2 body na hranu
        for (int i = 0; i < neighbor_cnt; i++) {
            int nv_type = agent_placement[neighbors[vertex][i]];
            if (nv_type == 1) score_delta += 2;
            // ak je tam T2 alebo nic tak to neprida body
        }

        branch_and_bound(current_index + 1, t1_remaining - 1, t2_remaining, agent_placement, current_network_score + score_delta,
                         vertex_order, vertex_degree, best_possible_add);
        agent_placement[vertex] = 0; // vratime to spat
    }

    // teraz skusim T2 agenta na tento vrchol
    if (t2_remaining > 0) {
        agent_placement[vertex] = 2;
        int score_delta = 0;

        // T2 ma komplikovanejsie pravidla
        // s prazdnym vrcholom +1, s T1 +1, s T2 -1
        for (int i = 0; i < neighbor_cnt; i++) {
            int nv_type = agent_placement[neighbors[vertex][i]];
            if (nv_type == 0) score_delta += 1;
            else if (nv_type == 1) score_delta += 1;
            else if (nv_type == 2) score_delta -= 1;
        }

        branch_and_bound(current_index + 1, t1_remaining, t2_remaining - 1, agent_placement, current_network_score + score_delta,
                         vertex_order, vertex_degree, best_possible_add);
        agent_placement[vertex] = 0; // opat vratime
    }

    // a nakoniec skusim vobec tam nedat ziadneho agenta
    branch_and_bound(current_index + 1, t1_remaining, t2_remaining, agent_placement, current_network_score, vertex_order,
        vertex_degree, best_possible_add);
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int num_edges, num_t1_agents, num_t2_agents;
    std::cin >> num_vertices >> num_edges >> num_t1_agents >> num_t2_agents;

    // validacia vstupu aby nam nespadol program na nezmyselnych datach
    if (num_vertices > 30 || num_edges > 180 || num_t1_agents + num_t2_agents > num_vertices) {
        std::cout << "Wrong input\n";
        return 0;
    }

    // inicializujem si adjacency list pomocou linked listu
    std::vector<AdjNode*> graph(num_vertices, nullptr);
    memset(neighbor_count, 0, sizeof(neighbor_count));

    // nacitam hrany a budujem graf
    for (int i = 0; i < num_edges; i++) {
        int u, v;
        std::cin >> u >> v;
        u--; v--; // pretoze indexujeme od 0

        // pridavam hranu do linked listu (neorientovany graf takze obe smery)
        auto* edge_a = new AdjNode(v);
        edge_a->next = graph[u];
        graph[u] = edge_a;

        auto* edge_b = new AdjNode(u);
        edge_b->next = graph[v];
        graph[v] = edge_b;

        // zaroven si plnim rychle pole susedov aby som nemusela prechadzat linked list stale
        // toto je rychlejsie pri branchovani
        neighbors[u][neighbor_count[u]++] = v;
        neighbors[v][neighbor_count[v]++] = u;
    }

    // tu si pocitam stupne vrcholov a zoradim ich
    // chcem zacat od vrcholov s najvyssim stupnom lebo maju najvacsi potencial
    std::vector<std::pair<int,int>> degree_vertex_pairs;
    int* vertex_degree = new int[num_vertices];

    for (int i = 0; i < num_vertices; i++) {
        vertex_degree[i] = neighbor_count[i];
        degree_vertex_pairs.push_back({neighbor_count[i], i});
    }

    // zoradenie podla stupna zostupne
    std::sort(degree_vertex_pairs.begin(), degree_vertex_pairs.end(),std::greater<std::pair<int,int>>());

    int* vertex_order = new int[num_vertices];
    int* best_possible_add = new int[num_vertices];

    // pripravim si poradia vrcholov a ich max mozne prispevky
    for (int i = 0; i < num_vertices; i++) {
        vertex_order[i] = degree_vertex_pairs[i].second;
        // T1 agent moze dat max 2 body na kazdu hranu takze to je optimisticke maximum
        best_possible_add[i] = vertex_degree[vertex_order[i]] * 2;
    }

    // pole kde si pamatam aky agent je na ktorom vrchole (0=ziadny, 1=T1, 2=T2)
    int* agent_placement = new int[num_vertices];
    memset(agent_placement, 0, num_vertices * sizeof(int));

    // pustime branch and bound algoritmus
    branch_and_bound(0, num_t1_agents, num_t2_agents, agent_placement, 0, vertex_order,
        vertex_degree, best_possible_add);

    // vypiseme najlepsi najdeny vysledok
    std::cout << best_score << "\n";

    // uvolnujem pamat aby nebol memory leak
    for (int i = 0; i < num_vertices; i++) {
        AdjNode* current = graph[i];
        while (current) {
            AdjNode* temp = current;
            current = current->next;
            delete temp;
        }
    }
    delete[] vertex_degree;
    delete[] vertex_order;
    delete[] agent_placement;
    delete[] best_possible_add;

    return 0;
}
//
// Created by bobenade on 16/11/2025.
//

//Moje teoreticke okienko k C++ :)
// v C++ set je zoradene poradie (ak dam do setu "7" "5" "1" vrati mi 1 5 7) a nedovoli mi robit duplitikaty - je to kolekcia unikatnych hodnot
        //vektor je nezoradene (ak dam do vektora "7" "5" "1" vrati mi 7 5 1)
        //existuje aj unordered set => ked ma nezaujima poradie ale chcem kolekciu unikatnych hodnot (bez duplikatov)

#include <algorithm>
#include <iostream>
#include <queue>
#include <vector>
#include <unordered_set>
#include <climits>

bool in_range(long long x, long long min, long long max) {
    return x >= min && x <= max;
}

bool in_range_noisy(long long x, long long min, long long max) {
    return x >= min && x < max;
}

//struct na aktualny stav
struct State {
    int mouse_pos;      //pozicia mysky
    int cat_max_dist;       //maximalna vzdialenost, na ktoru moze kocur dojst
    int distance;       //kolko ktokov myska presla
    int noisy_count;    //kolko hlucnych uzlov myska presla

    bool operator>(const State &other) const {
        if (distance != other.distance) {
            return distance > other.distance;
        }
        return noisy_count > other.noisy_count;
    }
};

// BFS pre najkratsie vzdialenosti z daneho uzla
std::vector<int> compute_distances(int start, const std::vector<std::vector<int>>& graph) {
    int n = graph.size();
    std::vector<int> dist(n, INT_MAX);
    std::queue<int> q;

    dist[start] = 0;
    q.push(start);

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        for (int v : graph[u]) {
            if (dist[v] == INT_MAX) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }

    return dist;
}

int main() {
    // N = num_nodes,
    // H = num_noisy_nodes,
    // E = num_edges

    int num_nodes, num_noisy_nodes, num_edges;
    std::cin >> num_nodes >> num_noisy_nodes >> num_edges;

    // S = mouse_start_idx,
    // C = mouse_end_idx,
    // K = cat_start_idx,
    // M = cat_max_jumps

    int mouse_start_idx, mouse_end_idx, cat_start_idx, cat_max_jumps;
    std::cin >> mouse_start_idx >> mouse_end_idx >> cat_start_idx >> cat_max_jumps;


    if (!(in_range(num_nodes, 10, (2 * 100000)) &&
          in_range_noisy(num_noisy_nodes, 1, num_nodes - 3) &&
          in_range(cat_max_jumps, 1, 50) &&
          in_range(num_edges * cat_max_jumps, 20, 10000000))) {
        std::cout << "Wrong input!\n";
        return 1;
    }

    std::vector<int> noisy_nodes(num_noisy_nodes);
    for (int i = 0; i < num_noisy_nodes; i++) {
        std::cin >> noisy_nodes[i];
        // std::cout << "Loaded noisy_node_" << (i+1) << " = " << noisy_nodes[i] << "\n";
    }

    std::unordered_set<int> noisy_set(noisy_nodes.begin(), noisy_nodes.end());
    //nacitavanie hlucnych uzlov do setu (neopakuju sa, nie su nikaj extra zoradene)

    //test setu - ako (ci vobec) funguje
    // for (int node : noisy_set) {
    //     std::cout << node << " ";
    // }

    std::vector<std::vector<int> > graph(num_nodes);
    for (int i = 0; i < num_edges; i++) {
        int edge_1, edge_2;
        std::cin >> edge_1 >> edge_2;
        graph[edge_1].push_back(edge_2);
        graph[edge_2].push_back(edge_1); // graf je neorientovany
    }

    // vzdialenosti z pozicie kocoura do vsetkych uzlov
    std::vector<int> cat_distances = compute_distances(cat_start_idx, graph);

    //vytvorim zaciatocny stav a pridam ho do fronty
    State initial_state;
    initial_state.mouse_pos = mouse_start_idx;
    initial_state.cat_max_dist = 0; // kocur este neskocil, je na zaciatku
    initial_state.distance = 0;
    initial_state.noisy_count = 0;
    //initial_state.path = {mouse_start_idx};

    std::priority_queue<State, std::vector<State>, std::greater<State> > pq;

    // visited: [mouse_pos][cat_max_dist] -> (min_distance, min_noisy)
    std::vector<std::vector<std::pair<int, int>>> visited(num_nodes,
        std::vector<std::pair<int, int>>(cat_max_jumps + 1, {INT_MAX, INT_MAX}));

    pq.push(initial_state);
    visited[initial_state.mouse_pos][initial_state.cat_max_dist] = {0, 0};

    //BFS
    while (!pq.empty()) {
        State current = pq.top();
        pq.pop();

        //Kontroljem ci som dosiahla ciel
        if (current.mouse_pos == mouse_end_idx) {
            std::cout << current.distance << " " << current.noisy_count << "\n";

            // // DEBUG: Vypisem celu cestu
            // std::cout << "Cesta mysicky: ";
            // for (int node: current.path) {
            //     std::cout << node;
            //     if (noisy_set.count(node) > 0) {
            //         std::cout << "(H)"; // Oznacim hlucne uzly
            //     }
            //     std::cout << " -> ";
            // }
            // std::cout << "CIEL\n";
            // //koniec debugu

            return 0;
        }

        // Skip ak som uz nasla lepsiu cestu do tohto stavu
        if (current.distance > visited[current.mouse_pos][current.cat_max_dist].first ||
            (current.distance == visited[current.mouse_pos][current.cat_max_dist].first &&
             current.noisy_count > visited[current.mouse_pos][current.cat_max_dist].second)) {
            continue;
        }

        //prejdem vsetkych susedov mysky
        for (int neighbor: graph[current.mouse_pos]) {
            //zistim ci je moj sused hlucny uzol
            bool is_noisy = (noisy_set.count(neighbor) > 0);

            //vypocitam si novu maximalnu vzdialenost pre kocura
            int new_cat_max_dist = current.cat_max_dist;

            if (is_noisy && current.cat_max_dist < cat_max_jumps) {
                //ak je to hlucny uzol - kocurik moze skocit (ak ma skoky)
                new_cat_max_dist = current.cat_max_dist + 1;
            }

            //kontrolujem bezpecnost - ci moze kocur dojst na poziciu mysky
            // Kocur moze dojst na uzol `neighbor` ak ma vzdialenost <= new_cat_max_dist
            if (cat_distances[neighbor] <= new_cat_max_dist) {
                //je to NEBEZPECNE, mys by mohla narazit na kocura - neskac tam
                continue;
            }

            // Vypocitame novy stav
            int new_distance = current.distance + 1;
            int new_noisy_count = current.noisy_count + (is_noisy ? 1 : 0);

            //kontrolujem ci je tento stav lepsi nez existujuci
            auto& best = visited[neighbor][new_cat_max_dist];
            if (new_distance < best.first ||
                (new_distance == best.first && new_noisy_count < best.second)) {

                best = {new_distance, new_noisy_count};

                // Ak je to BEZPECNE - vytvorim novy stav a pridam do fronty
                State new_state;
                new_state.mouse_pos = neighbor;
                new_state.cat_max_dist = new_cat_max_dist;
                new_state.distance = new_distance;
                new_state.noisy_count = new_noisy_count;
                //new_state.path = current.path; //skopirujem cestu
                //new_state.path.push_back(neighbor); //pridam novy uzol

                pq.push(new_state);
            }
        }
    }

    return 0;
}